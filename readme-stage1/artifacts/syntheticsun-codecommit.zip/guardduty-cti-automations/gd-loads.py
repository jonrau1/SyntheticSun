import os
import boto3
import datetime
# create boto3 clients
s3 = boto3.resource('s3')
guardduty = boto3.client('guardduty')
dynamodb = boto3.client('dynamodb')
scanPaginator = dynamodb.get_paginator('scan')
# artifact bucket
threatListS3Bucket = os.environ['SYNTHETIC_SUN_ARTIFACT_BUCKET']
# gd detector Id
gdDetectorId = os.environ['GUARDDUTY_DETECTOR_ID']
# variables for CTI
ctiDdbTable = os.environ['MISP_IP_IOC_DDB_TABLE']
ctiThreatIntelSetId = os.environ['CTI_THREAT_INTEL_SET_ID']
# variables for anomalies
anomalyDdbTable = os.environ['IP_INSIGHTS_DDB_TABLE']
anomalyThreatIntelSetId = os.environ['ANOMALY_THREAT_INTEL_SET_ID']

def cti_threat_intel_set_update():
    # create writer object
    f = open('./cti-threatlist.txt','w')
    # perform a paginated scan on ddb table
    # parse our IP-based IOCs and write them to the file with a new line
    iterator = scanPaginator.paginate(TableName=ctiDdbTable)
    for page in iterator:
        for item in page['Items']:
            ipAddress = str(item['IPV4_IOC']['S'])
            try:
                ipv4Check = ipaddress.IPv4Address(ipAddress)
                f.write(ipAddress + '/32' + '\n')
            except:
                pass
    # close out the file
    f.close()
    # upload threat list to s3
    response = s3.meta.client.upload_file('./cti-threatlist.txt', threatListS3Bucket, 'cti-threatlist.txt')
    objectUrl = 'https://' + threatListS3Bucket + '.s3.amazonaws.com/cti-threatlist.txt' 
    # update GuardDuty threat list
    try:
        response = guardduty.update_threat_intel_set(
            DetectorId=gdDetectorId,
            ThreatIntelSetId=ctiThreatIntelSetId,
            Location=objectUrl,
            Activate=True
        )
        print(response)
    except Exception as e:
        print(e)
        raise

def ipinsights_threat_intel_set_update():
    # create writer object
    f = open('./anomaly-threatlist.txt','w')
    # perform a paginated scan on ddb table
    # parse our IP-based IOCs and write them to the file with a new line
    iterator = scanPaginator.paginate(TableName=anomalyDdbTable)
    for page in iterator:
        for item in page['Items']:
            ipAddress = str(item['IPV4_IOC']['S'])
            try:
                ipv4Check = ipaddress.IPv4Address(ipAddress)
                f.write(ipAddress + '/32' + '\n')
            except:
                pass
    # close out the file
    f.close()
    # upload threat list to s3
    response = s3.meta.client.upload_file('./anomaly-threatlist.txt', threatListS3Bucket, 'anomaly-threatlist.txt')
    objectUrl = 'https://' + threatListS3Bucket + '.s3.amazonaws.com/anomaly-threatlist.txt' 
    # update GuardDuty threat list
    try:
        response = guardduty.update_threat_intel_set(
            DetectorId=gdDetectorId,
            ThreatIntelSetId=anomalyThreatIntelSetId,
            Location=objectUrl,
            Activate=True
        )
        print(response)
    except Exception as e:
        print(e)
        raise

def guardduty_threat_intel_update():
    cti_threat_intel_set_update()
    ipinsights_threat_intel_set_update()

guardduty_threat_intel_update()