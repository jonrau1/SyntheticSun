import requests
from requests_aws4auth import AWS4Auth
import time
import os
import json
import boto3
import ipaddress
import socket
import base64
import zlib
import datetime
def lambda_handler(event, context):
    # import clients
    ec2 = boto3.client('ec2')
    dynamodb = boto3.client('dynamodb')
    # create variables for aws4auth, es and ddb
    awsRegion = os.environ['AWS_REGION']
    accessKey = os.environ['AWS_ACCESS_KEY_ID']
    secretAccessKey = os.environ['AWS_SECRET_ACCESS_KEY']
    seshToken = os.environ['AWS_SESSION_TOKEN']
    tableName = os.environ['IP_IOC_DYNAMODB_TABLE']
    host = os.environ['ELASTICSEARCH_URL']
    index = 'vpc-flows'
    # create auth token for ES
    awsAuthToken = AWS4Auth(accessKey, secretAccessKey, awsRegion, 'es', session_token=seshToken)
    # create requests items
    url = host + '/' + index + '/' + '_doc/'
    headers = { "Content-Type": "application/json" }
    # grab the 'awslogs' part of the CWL event stream
    data = event.get('awslogs', {}).get('data')
    # Base64 Decode, decompress with ZLIB, load into a dict with json.loads
    records = json.loads(zlib.decompress(base64.b64decode(data), 16 + zlib.MAX_WBITS))
    # Loop through the flow log message
    for flows in records['logEvents']:
        # split the string to grab values, these are number coded above the modules in the comments
        flowLogRaw = flows['message'].split()
        acctId = flowLogRaw[1]
        interfaceId = flowLogRaw[2]
        sourceIp = flowLogRaw[3]
        destIp = flowLogRaw[4]
        sourcePort = flowLogRaw[5]
        destPort = flowLogRaw[6]
        ianaProtocol = flowLogRaw[7]
        pktXfer = flowLogRaw[8]
        bytesXfer = flowLogRaw[9]
        flowAction = flowLogRaw[12]
        # create an ARN for the ENIs for cross-reference
        eniArn = 'arn:aws:ec2:' + awsRegion + ':' + acctId + ':network-interface/' + interfaceId
        # create a date
        date = datetime.datetime.now().replace(microsecond=0).isoformat()

    if sourceIp == '-':
        pass
    else:

        def source_ip_checker():
            rfc1918Check = ipaddress.IPv4Address(sourceIp)
            if rfc1918Check.is_private:
                countryCode = str('Unidentified')
                latitude = int(0)
                longitude = int(0)
                isp = str('Unidentified')
                org = str('Unidentified')
                asn = str('Unidentified')
                asnName = str('Unidentified')
                geoLoc = { 'srcLat': latitude, 'srcLon': longitude, 'srcCountryCode': countryCode, 'srcIsp': isp, 'srcOrg': org, 'srcAs': asn, 'srcAsname': asnName }
                geoData = json.dumps(geoLoc)
                return geoData
            else:
                url = 'http://ip-api.com/json/' + sourceIp + '?fields=status,message,countryCode,lat,lon,isp,org,as,asname'
                r = requests.get(url)
                # handle throttling
                reqRemain = int(r.headers['X-Rl'])
                if reqRemain == 0:
                    ttl = int(r.headers['X-Ttl'])
                    waitTime = ttl + 1
                    time.sleep(waitTime)
                else:
                    ipJson = r.json()
                    countryCode = str(ipJson['countryCode'])
                    latitude = float(ipJson['lat'])
                    longitude = float(ipJson['lon'])
                    isp = str(ipJson['isp'])
                    org = str(ipJson['org'])
                    asn = str(ipJson['as'])
                    asnName = str(ipJson['asname'])
                    geoLoc = { 'srcLat': latitude, 'srcLon': longitude, 'srcCountryCode': countryCode, 'srcIsp': isp, 'srcOrg': org, 'srcAs': asn, 'srcAsname': asnName }
                    geoData = json.dumps(geoLoc)
                    return geoData

        def dest_ip_checker():
            rfc1918Check = ipaddress.IPv4Address(destIp)
            if rfc1918Check.is_private:
                countryCode = str('Unidentified')
                latitude = int(0)
                longitude = int(0)
                isp = str('Unidentified')
                org = str('Unidentified')
                asn = str('Unidentified')
                asnName = str('Unidentified')
                geoLoc = { 'destLat': latitude, 'destLon': longitude, 'destCountryCode': countryCode, 'destIsp': isp, 'destOrg': org, 'destAs': asn, 'destAsname': asnName }
                geoData = json.dumps(geoLoc)
                return geoData
            else:
                url = 'http://ip-api.com/json/' + destIp + '?fields=status,message,countryCode,lat,lon,isp,org,as,asname'
                r = requests.get(url)
                # handle throttling
                reqRemain = int(r.headers['X-Rl'])
                if reqRemain == 0:
                    ttl = int(r.headers['X-Ttl'])
                    waitTime = ttl + 1
                    time.sleep(waitTime)
                else:
                    ipJson = r.json()
                    countryCode = str(ipJson['countryCode'])
                    latitude = float(ipJson['lat'])
                    longitude = float(ipJson['lon'])
                    isp = str(ipJson['isp'])
                    org = str(ipJson['org'])
                    asn = str(ipJson['as'])
                    asnName = str(ipJson['asname'])
                    geoLoc = { 'destLat': latitude, 'destLon': longitude, 'destCountryCode': countryCode, 'destIsp': isp, 'destOrg': org, 'destAs': asn, 'destAsname': asnName }
                    geoData = json.dumps(geoLoc)
                    return geoData

        def source_instance_or_dns_finder():
            rfc1918Check = ipaddress.IPv4Address(sourceIp)
            if rfc1918Check.is_private:
                try:
                    response = ec2.describe_instances(Filters=[{'Name':'private-ip-address','Values': [sourceIp]}])
                    if str(response['Reservations']) == '[]':
                        sourceReverseDomain = 'Unidentified'
                        sourceInstanceId = 'None'
                        sourceInstanceArn = 'None'
                        ec2Intel = { 'sourceReverseDomain': sourceReverseDomain, 'sourceInstanceId': sourceInstanceId, 'sourceInstanceArn': sourceInstanceArn }
                        sourceEc2Data = json.dumps(ec2Intel)
                        return sourceEc2Data
                    else:
                        sourceReverseDomain = str(response['Reservations'][0]['Instances'][0]['PrivateDnsName'])
                        sourceInstanceId = str(response['Reservations'][0]['Instances'][0]['InstanceId'])
                        sourceInstanceArn = 'arn:aws:ec2:' + awsRegion + ':' + acctId + ':instance/' + sourceInstanceId
                        ec2Intel = { 'sourceReverseDomain': sourceReverseDomain, 'sourceInstanceId': sourceInstanceId, 'sourceInstanceArn': sourceInstanceArn }
                        sourceEc2Data = json.dumps(ec2Intel)
                        return sourceEc2Data
                except Exception as e:
                    print(e)
                    raise
            else:
                try:
                    sourceReverseDomain = str(socket.gethostbyaddr(sourceIp)[0])
                except:
                    sourceReverseDomain = 'Unidentified'
                sourceInstanceId = 'None'
                sourceInstanceArn = 'None'
                ec2Intel = { 'sourceReverseDomain': sourceReverseDomain, 'sourceInstanceId': sourceInstanceId, 'sourceInstanceArn': sourceInstanceArn }
                sourceEc2Data = json.dumps(ec2Intel)
                return sourceEc2Data

        def dest_instance_or_dns_finder():
            rfc1918Check = ipaddress.IPv4Address(destIp)
            if rfc1918Check.is_private:
                try:
                    response = ec2.describe_instances(Filters=[{'Name':'private-ip-address','Values': [destIp]}])
                    if str(response['Reservations']) == '[]':
                        destReverseDomain = 'Unidentified'
                        destInstanceId = 'None'
                        destInstanceArn = 'None'
                        ec2Intel = { 'destReverseDomain': destReverseDomain, 'destInstanceId': destInstanceId, 'destInstanceArn': destInstanceArn }
                        destEc2Data = json.dumps(ec2Intel)
                        return destEc2Data
                    else:
                        destReverseDomain = str(response['Reservations'][0]['Instances'][0]['PrivateDnsName'])
                        destInstanceId = str(response['Reservations'][0]['Instances'][0]['InstanceId'])
                        destInstanceArn = 'arn:aws:ec2:' + awsRegion + ':' + acctId + ':instance/' + destInstanceId
                        ec2Intel = { 'destReverseDomain': destReverseDomain, 'destInstanceId': destInstanceId, 'destInstanceArn': destInstanceArn }
                        destEc2Data = json.dumps(ec2Intel)
                        return destEc2Data
                except Exception as e:
                    print(e)
                    raise
            else:
                try:
                    destReverseDomain = str(socket.gethostbyaddr(destIp)[0])
                except:
                    destReverseDomain = 'Unidentified'
                destInstanceId = 'None'
                destInstanceArn = 'None'
                ec2Intel = { 'destReverseDomain': destReverseDomain, 'destInstanceId': destInstanceId, 'destInstanceArn': destInstanceArn }
                destEc2Data = json.dumps(ec2Intel)
                return destEc2Data

        def threat_intel_enrichment():
            # Scan for source IP matches
            try:
                response = dynamodb.query(
                    TableName=tableName,
                    KeyConditions={
                        'ip-address': {
                            'AttributeValueList': [
                                {
                                    'S': sourceIp
                                }
                            ],
                            'ComparisonOperator': 'EQ'
                        }
                    }
                )
                if str(response['Items']) == '[]':
                    sourceThreatMatch = 'False'
                else:
                    sourceThreatMatch = 'True'
            except Exception as e:
                print(e)
            # Scan for destination IP matches
            try:
                response = dynamodb.query(
                    TableName=tableName,
                    KeyConditions={
                        'ip-address': {
                            'AttributeValueList': [
                                {
                                    'S': destIp
                                }
                            ],
                            'ComparisonOperator': 'EQ'
                        }
                    }
                )
                if str(response['Items']) == '[]':
                    destThreatMatch = 'False'
                else:
                    destThreatMatch = 'True'
            except Exception as e:
                print(e)
            # create threat intel dict
            ipThreatIntel = { 'sourceThreatMatch': sourceThreatMatch, 'destThreatMatch': destThreatMatch }
            threatData = json.dumps(ipThreatIntel)
            return threatData

        def flow_log_decorator():
            # Source IP GeoInt
            srcGeoDict = json.loads(source_ip_checker())
            sourceIpLatid = float(srcGeoDict['srcLat'])
            sourceIpLongt = float(srcGeoDict['srcLon'])
            sourceIpCountry = str(srcGeoDict['srcCountryCode'])
            sourceIsp = str(srcGeoDict['srcIsp'])
            sourceOrg = str(srcGeoDict['srcOrg'])
            sourceAs = str(srcGeoDict['srcAs'])
            sourceAsname = str(srcGeoDict['srcAsname'])
            # Dest IP GeoInt
            destGeoDict = json.loads(dest_ip_checker())
            destIpLatid = float(destGeoDict['destLat'])
            destIpLongt = float(destGeoDict['destLon'])
            destIpCountry = str(destGeoDict['destCountryCode'])
            destIsp = str(destGeoDict['destIsp'])
            destOrg = str(destGeoDict['destOrg'])
            destAs = str(destGeoDict['destAs'])
            destAsname = str(destGeoDict['destAsname'])
            # Source Instance Information
            srcInstDict = json.loads(source_instance_or_dns_finder())
            sourceReverseDomain = str(srcInstDict['sourceReverseDomain'])
            sourceInstanceId = str(srcInstDict['sourceInstanceId'])
            sourceInstanceArn = str(srcInstDict['sourceInstanceArn'])
            # Destination Instance Information
            destInstDict = json.loads(dest_instance_or_dns_finder())
            destReverseDomain = str(destInstDict['destReverseDomain'])
            destInstanceId = str(destInstDict['destInstanceId'])
            destInstanceArn = str(destInstDict['destInstanceArn'])
            # Threat Intelligence Information
            threatIntDict = json.loads(threat_intel_enrichment())
            sourceThreatMatch = str(threatIntDict['sourceThreatMatch'])
            destThreatMatch = str(threatIntDict['destThreatMatch'])
            # create new flow log dict
            flowLogRaw = {
                'accountId': acctId,
                'interfaceId': interfaceId,
                'interfaceArn': eniArn,
                'packets': pktXfer,
                'bytes' :bytesXfer,
                'sourceInstanceId': sourceInstanceId,
                'sourceInstanceArn': sourceInstanceArn,
                'sourceIp': sourceIp,
                'sourceIpIsThreat': sourceThreatMatch,
                'sourceReverseDomain': sourceReverseDomain,
                'sourceLocation': {
                    'lat': sourceIpLatid,'lon': sourceIpLongt
                },
                'sourceIpCountry': sourceIpCountry,
                'sourceIsp': sourceIsp,
                'sourceOrg': sourceOrg,
                'sourceAs': sourceAs,
                'sourceAsname': sourceAsname,
                'destInstanceId': destInstanceId,
                'destInstanceArn': destInstanceArn,
                'destIp': destIp,
                'destIpIsThreat': destThreatMatch,
                'destReverseDomain': destReverseDomain,
                'destinationLocation': {
                    'lat': destIpLatid,'lon': destIpLongt
                },
                'destIpCountry': destIpCountry,
                'destIsp': destIsp,
                'destOrg': destOrg,
                'destAs': destAs,
                'destAsname': destAsname,
                'sourcePort': sourcePort,
                'destPort': destPort,
                'protocol': ianaProtocol,
                'date': date,
                'action': flowAction
            }
            # dump into a better looking dictionary
            # default=str will stop that pesky "Object of type datetime is not JSON serializable" error you'll get
            geoIntFlowLog = json.dumps(flowLogRaw, default=str)
            r = requests.post(url, auth=awsAuthToken, data=geoIntFlowLog, headers=headers)
            print(r.json())

        def main():
            source_ip_checker()
            dest_ip_checker()
            source_instance_or_dns_finder()
            dest_instance_or_dns_finder()
            threat_intel_enrichment()
            flow_log_decorator()

        main()