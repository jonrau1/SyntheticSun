import json
import boto3
import gzip
import os
import socket
from requests_aws4auth import AWS4Auth
import requests
import time
import re
import datetime

def lambda_handler(event, context):
    # import boto3 clients
    s3 = boto3.client('s3')
    elbv2 = boto3.client('elbv2')
    dynamodb = boto3.client('dynamodb')
    sts = boto3.client('sts')
    # create region and account object
    awsAccountId = sts.get_caller_identity()['Account']
    awsRegion = os.environ['AWS_REGION']
    # create a user-agent regex
    regex = '\"(?P<http_user_agent>[^\"]+)'
    # loop through list of s3 events
    for r in event['Records']:
        # abort if the file is larger than 512MB
        objectSize = int(r['s3']['object']['size'])
        if objectSize >= 536870911:
            pass
        else:
            bucketName = str(r['s3']['bucket']['name'])
            keyName = str(r['s3']['object']['key'])
            # create local file path in Lambda
            localFilePath = '/tmp/' + keyName.split('/')[-1]
            # download waf log to Lambda /tmp
            s3.download_file(bucketName, keyName, localFilePath)
            try:
                with gzip.open(localFilePath, 'r') as f:
                    lines = f.readlines()
                    for line in lines:
                        # decode bytes and split log file to pull out specific keys
                        x = line.decode('utf-8')
                        uaMatch = re.split(regex, x)
                        userAgent = str(uaMatch[5])
                        if userAgent == '-' or '':
                            userAgent = 'Unidentified'
                        else:
                            userAgent = str(uaMatch[5])
                        r = line.decode('utf-8').split()
                        trafficType = str(r[0])
                        elbTimestamp = str(r[1])
                        elbId = str(r[2])
                        elbArn = 'arn:aws:elasticloadbalancing:' + awsRegion + ':' + awsAccountId + ':loadbalancer/' + elbId
                        try:
                            response = elbv2.describe_load_balancers(LoadBalancerArns=[elbArn])
                            elbName = str(response['LoadBalancers'][0]['LoadBalancerName'])
                            elbVpcId = str(response['LoadBalancers'][0]['VpcId'])
                        except:
                            elbName = 'None'
                            elbVpcId = 'None'
                        # separate port information from the Client IP
                        rawClientIpPort = str(r[3])
                        clientIp = rawClientIpPort.split(":")[0]
                        clientPort = rawClientIpPort.split(":")[1]
                        statusCode = str(r[8])
                        receivedBytes = int(r[10])
                        sentBytes = int(r[11])
                        httpMethod = str(r[12]).replace('"','')
                        uri = str(r[13])
                        httpVersion = str(r[14]).replace('"','')
                        
                        def client_ip_geoint_dns():
                            # attempt to get hostname and FQDN of Client IP
                            try:
                                clientReverseDomain = str(socket.gethostbyaddr(clientIp)[0])
                            except:
                                clientReverseDomain = 'Unidentified'
                            # retrieve GEOINT for Client IP
                            url = 'http://ip-api.com/json/' + clientIp + '?fields=status,message,countryCode,lat,lon,isp,org,as,asname'
                            r = requests.get(url)
                            # handle throttling
                            reqRemain = int(r.headers['X-Rl'])
                            if reqRemain == 0:
                                ttl = int(r.headers['X-Ttl'])
                                waitTime = ttl + 1
                                time.sleep(waitTime)
                            else:
                                ipJson = r.json()
                                countryCode = str(ipJson['countryCode'])
                                latitude = float(ipJson['lat'])
                                longitude = float(ipJson['lon'])
                                isp = str(ipJson['isp'])
                                org = str(ipJson['org'])
                                asn = str(ipJson['as'])
                                asnName = str(ipJson['asname'])
                                geoLoc = { 'clientReverseDomain': clientReverseDomain, 'clientLat': latitude, 'clientLon': longitude, 
                                'clientCountryCode': countryCode, 'clientIsp': isp, 'clientOrg': org, 'clientAs': asn, 'clientAsname': asnName }
                                geoData = json.dumps(geoLoc)
                                return geoData
                    
                        def threat_intel_enrichment():
                            # grab the reverse domain of the client
                            h = json.loads(client_ip_geoint_dns())
                            clientReverseDomain = str(h['clientReverseDomain'])
                            # import tables
                            ipIocTable = os.environ['IP_IOC_DYNAMODB_TABLE']
                            domainIocTable = os.environ['DOMAIN_IOC_DYNAMODB_TABLE']
                            # check if the hostname (if matched)
                            # matches any threats
                            if clientReverseDomain != 'Unidentified':
                                try:
                                    response = dynamodb.query(
                                        TableName=domainIocTable,
                                        KeyConditions={
                                            'DOMAIN_IOC': {
                                                'AttributeValueList': [
                                                    {
                                                        'S': clientReverseDomain
                                                    }
                                                ],
                                                'ComparisonOperator': 'EQ'
                                            }
                                        }
                                    )
                                    if str(response['Items']) == '[]':
                                        clientReverseDomainThreatMatch = 'False'
                                    else:
                                        clientReverseDomainThreatMatch = 'True'
                                except Exception as e:
                                    print(e)
                            else:
                                clientReverseDomainThreatMatch = 'False'
                            # check if IP matches any threats
                            try:
                                response = dynamodb.query(
                                    TableName=ipIocTable,
                                    KeyConditions={
                                        'IPV4_IOC': {
                                            'AttributeValueList': [
                                                {
                                                    'S': clientIp
                                                }
                                            ],
                                            'ComparisonOperator': 'EQ'
                                        }
                                    }
                                )
                                if str(response['Items']) == '[]':
                                    clientIpThreatMatch = 'False'
                                else:
                                    clientIpThreatMatch = 'True'
                            except Exception as e:
                                print(e)
                            # create threat intel dict
                            ipThreatIntel = { 'clientReverseDomainThreatMatch': clientReverseDomainThreatMatch, 'clientIpThreatMatch': clientIpThreatMatch }
                            threatData = json.dumps(ipThreatIntel)
                            return threatData
                        
                        def elb_log_enrichment():
                            # Parse GeoInt data from ALB
                            g = json.loads(client_ip_geoint_dns())
                            clientReverseDomain = str(g['clientReverseDomain'])
                            clientLat = float(g['clientLat'])
                            clientLon = float(g['clientLon'])
                            clientCountryCode = str(g['clientCountryCode'])
                            clientIsp = str(g['clientIsp'])
                            clientOrg = str(g['clientOrg'])
                            clientAs = str(g['clientAs'])
                            clientAsname = str(g['clientAsname'])
                            # Parse Threat Intel data from ALB
                            cti = json.loads(threat_intel_enrichment())
                            domainThreat = str(cti['clientReverseDomainThreatMatch'])
                            ipThreat = str(cti['clientIpThreatMatch'])
                            # create a new json dict
                            date = datetime.datetime.now().replace(microsecond=0).isoformat()
                            payload = {
                                'trafficType': trafficType,
                                'timestamp': date,
                                'elbTimestamp': elbTimestamp,
                                'elbName': elbName,
                                'elbArn': elbArn,
                                'elbVpcId': elbVpcId,
                                'clientIp': clientIp,
                                'clientIpThreatMatch': ipThreat,
                                'clientReverseDomain': clientReverseDomain,
                                'clientHostnameThreatMatch': domainThreat,
                                'location': {'lat': clientLat, 'lon': clientLon},
                                'clientCountryCode': clientCountryCode,
                                'clientIsp': clientIsp,
                                'clientOrg': clientOrg,
                                'clientPort': clientPort,
                                'clientAs': clientAs,
                                'clientAsname': clientAsname,
                                'receivedBytes': receivedBytes,
                                'sentBytes': sentBytes,
                                'httpMethod': httpMethod,
                                'uri': uri,
                                'httpVersion': httpVersion,
                                'userAgent': userAgent,
                                'statusCode': statusCode
                            }
                            elbJson = json.dumps(payload, default=str)
                            # import variables
                            awsRegion = os.environ['AWS_REGION']
                            accessKey = os.environ['AWS_ACCESS_KEY_ID']
                            secretAccessKey = os.environ['AWS_SECRET_ACCESS_KEY']
                            seshToken = os.environ['AWS_SESSION_TOKEN']
                            # create auth token
                            awsAuthToken = AWS4Auth(accessKey, secretAccessKey, awsRegion, 'es', session_token=seshToken)
                            host = os.environ['ELASTICSEARCH_URL']
                            index = 'app-load-balancer'
                            # create requests items
                            url = host + '/' + index + '/' + '_doc/'
                            headers = { "Content-Type": "application/json" }
                            r = requests.post(url, auth=awsAuthToken, data=elbJson, headers=headers)
                            print(r.json())
                    
                        def mains():
                            client_ip_geoint_dns()
                            threat_intel_enrichment()
                            elb_log_enrichment()
                    
                        mains()
                        
            except Exception as e:
                print(e)