import os
import json
import base64
import zlib
import boto3
import ipaddress
import requests
import time
import socket
import datetime
from requests_aws4auth import AWS4Auth
def lambda_handler(event, context):
    # create boto3 clients/reclients
    dynamodbReclient = boto3.resource('dynamodb')
    dynamodb = boto3.client('dynamodb')
    runtime = boto3.client('sagemaker-runtime')
    # create os vars
    ipTable = os.environ['IP_IOC_DYNAMODB_TABLE']
    domainTable = os.environ['MISP_DOMAIN_IOC_DDB_TABLE']
    smEndpoint = os.environ['SAGEMAKER_ENDPOINT']
    anomalyDdbTable = os.environ['ANOMALY_DYNAMODB_TABLE']
    # parse CWL event
    data = event.get('awslogs', {}).get('data')
    # Base64 Decode, decompress with ZLIB, load into a dict with json.loads
    records = json.loads(zlib.decompress(base64.b64decode(data), 16 + zlib.MAX_WBITS))
    # Loop through the flow log message
    for flows in records['logEvents']:
        rawlog = flows['message'].split(',')
        clientIp = str(rawlog[0])
        requestTimeEpoch = int(rawlog[1])
        httpMethod = str(rawlog[2])
        userAgent = str(rawlog[3])
        domainName = str(rawlog[4])
        routeKey = str(rawlog[5])
        status = str(rawlog[6])
        responseLength = int(rawlog[7])
        requestId = str(rawlog[8])
        isoTime = datetime.datetime.fromtimestamp(requestTimeEpoch, datetime.timezone.utc)
        isoString = str(isoTime)

        def client_geoint_enrichment():
            rfc1918Check = ipaddress.IPv4Address(clientIp)
            if rfc1918Check.is_private:
                countryCode = str('Unidentified')
                latitude = int(0)
                longitude = int(0)
                isp = str('Unidentified')
                org = str('Unidentified')
                asn = str('Unidentified')
                asnName = str('Unidentified')
                geoLoc = { 'srcLat': latitude, 'srcLon': longitude, 'srcCountryCode': countryCode, 'srcIsp': isp, 'srcOrg': org, 'srcAs': asn, 'srcAsname': asnName }
                geoData = json.dumps(geoLoc)
                return geoData
            else:
                url = 'http://ip-api.com/json/' + clientIp + '?fields=status,message,countryCode,lat,lon,isp,org,as,asname'
                r = requests.get(url)
                # handle throttling
                reqRemain = int(r.headers['X-Rl'])
                if reqRemain == 0:
                    ttl = int(r.headers['X-Ttl'])
                    waitTime = ttl + 1
                    time.sleep(waitTime)
                else:
                    ipJson = r.json()
                    countryCode = str(ipJson['countryCode'])
                    latitude = float(ipJson['lat'])
                    longitude = float(ipJson['lon'])
                    isp = str(ipJson['isp'])
                    org = str(ipJson['org'])
                    asn = str(ipJson['as'])
                    asnName = str(ipJson['asname'])
                    geoLoc = { 'srcLat': latitude, 'srcLon': longitude, 'srcCountryCode': countryCode, 'srcIsp': isp, 'srcOrg': org, 'srcAs': asn, 'srcAsname': asnName }
                    geoData = json.dumps(geoLoc)
                    return geoData

        def client_dns_enrichment():
            rfc1918Check = ipaddress.IPv4Address(clientIp)
            if rfc1918Check.is_private:
                clientHost = 'Unidentified'
                clientFqdn = 'Unidentified'
                clientDns = {'clientHost': clientHost, 'clientFqdn': clientFqdn}
                dnsDict = json.dumps(clientDns)
                return dnsDict
            else:
                clientHost = str(socket.gethostbyaddr(clientIp)[0])
                clientFqdn = socket.getfqdn(clientHost)
                clientDns = {'clientHost': clientHost, 'clientFqdn': clientFqdn}
                dnsDict = json.dumps(clientDns)
                return dnsDict

        def threat_intel_check():
            clientHost = str(socket.gethostbyaddr(clientIp)[0])
            # Scan for client IP matches
            try:
                response = dynamodb.query(
                    TableName=ipTable,
                    KeyConditions={
                        'IPV4_IOC': {
                            'AttributeValueList': [
                                {
                                    'S': clientIp
                                }
                            ],
                            'ComparisonOperator': 'EQ'
                        }
                    }
                )
                if str(response['Items']) == '[]':
                    clientIpThreatMatch = 'False'
                else:
                    clientIpThreatMatch = 'True'
            except Exception as e:
                print(e)
            # Scan for client hostname/domain matches
            try:
                response = dynamodb.query(
                    TableName=domainTable,
                    KeyConditions={
                        'DOMAIN_IOC': {
                            'AttributeValueList': [
                                {
                                    'S': clientHost
                                }
                            ],
                            'ComparisonOperator': 'EQ'
                        }
                    }
                )
                if str(response['Items']) == '[]':
                    clientHostnameThreatMatch = 'False'
                else:
                    clientHostnameThreatMatch = 'True'
            except Exception as e:
                print(e)
            clientCti = {'clientIpThreatMatch': clientIpThreatMatch, 'clientHostnameThreatMatch': clientHostnameThreatMatch}
            ctiDict = json.dumps(clientCti)
            return ctiDict

        def anomaly_detection():
            # create user-agent, IP pair with periods parsed out from the user-agent
            newUserAgent = userAgent.replace('.','')
            noCommas = newUserAgent.replace(',','')
            pair = noCommas + ',' + clientIp
            response = runtime.invoke_endpoint(EndpointName=smEndpoint,ContentType='text/csv',Body=pair)
            result = json.loads(response['Body'].read().decode())
            prediction = float(result['predictions'][0]['dot_product'])
            if prediction <= 0.03:
                iso8601 = datetime.datetime.now().isoformat()
                ts = int(time.time())
                ttl = int(ts + 8*86000)
                try:
                    table = dynamodbReclient.Table(anomalyDdbTable)
                    table.put_item(
                        Item={
                            'ANOMALY_IPV4': clientIp,
                            'entity': userAgent,
                            'iso-time': iso8601,
                            'ttl': ttl
                        }
                    )
                except Exception as e:
                    print(e)
                anomalyDict = { 'isAnomaly': 'True' }
                anomalyData = json.dumps(anomalyDict)
                return anomalyData
            else:
                anomalyDict = { 'isAnomaly': 'False' }
                anomalyData = json.dumps(anomalyDict)
                return anomalyData

        def apigw_decorator():
            # parse GEOINT
            geo = json.loads(client_geoint_enrichment())
            clientIpLatid = float(geo['srcLat'])
            clientIpLongt = float(geo['srcLon'])
            clientIpCountry = str(geo['srcCountryCode'])
            clientIsp = str(geo['srcIsp'])
            clientOrg = str(geo['srcOrg'])
            clientAs = str(geo['srcAs'])
            clientAsname = str(geo['srcAsname'])
            # parse DNS
            dns = json.loads(client_dns_enrichment())
            clientHost = str(dns['clientHost'])
            clientFqdn = str(dns['clientFqdn'])
            # parse THREATINT
            cti = json.loads(threat_intel_check())
            clientIpThreatMatch = str(cti['clientIpThreatMatch'])
            clientHostnameThreatMatch = str(cti['clientHostnameThreatMatch'])
            # parse Anomaly
            ano = json.loads(anomaly_detection())
            isAnomaly = str(ano['isAnomaly'])
            # reform log
            rawData = {
                'clientIp': clientIp,
                'date': isoString,
                'requestTimeEpoch': requestTimeEpoch,
                'httpMethod': httpMethod,
                'userAgent': userAgent,
                'domainName': domainName,
                'routeKey': routeKey,
                'status': status,
                'responseLength': responseLength,
                'requestId': requestId,
                'location': {
                    'lat': clientIpLatid,'lon': clientIpLongt
                },
                'clientCountryCode': clientIpCountry,
                'clientIsp': clientIsp,
                'clientOrg': clientOrg,
                'clientAs': clientAs,
                'clientAsname': clientAsname,
                'clientHost': clientHost,
                'clientFqdn': clientFqdn,
                'clientIpThreatMatch': clientIpThreatMatch,
                'clientHostnameThreatMatch': clientHostnameThreatMatch,
                'isAnomaly': isAnomaly
            }
            # bring in os vars for aws4auth
            data = json.dumps(rawData)
            awsRegion = os.environ['AWS_REGION']
            accessKey = os.environ['AWS_ACCESS_KEY_ID']
            secretAccessKey = os.environ['AWS_SECRET_ACCESS_KEY']
            seshToken = os.environ['AWS_SESSION_TOKEN']
            host = os.environ['ELASTICSEARCH_URL']
            index = 'apigw-accesslogs'
            # create requests items
            awsAuthToken = AWS4Auth(accessKey, secretAccessKey, awsRegion, 'es', session_token=seshToken)
            url = host + '/' + index + '/' + '_doc/'
            headers = { "Content-Type": "application/json" }
            r = requests.post(url, auth=awsAuthToken, data=data, headers=headers)
            print(r.json())

        def apigw_enrich():
            client_geoint_enrichment()
            client_dns_enrichment()
            threat_intel_check()
            anomaly_detection()
            apigw_decorator()

        apigw_enrich()