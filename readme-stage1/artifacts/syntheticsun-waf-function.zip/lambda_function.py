import requests
from requests_aws4auth import AWS4Auth
import time
import os
import json
import boto3
import socket
import datetime

def lambda_handler(event, context):
    for record in event['Records']:
        bucket_name = str(record['s3']['bucket']['name'])
        key_name = str(record['s3']['object']['key'])
        local_file_path = '/tmp/' + key_name.split('/')[-1]
        s3 = boto3.client('s3')
        dynamodb = boto3.client('dynamodb')
        dynamodbResource = boto3.resource('dynamodb')
        runtime = boto3.client('sagemaker-runtime')
        s3.download_file(bucket_name, key_name, local_file_path)
        try:
            with open(local_file_path,'r') as content:
                for line in content:
                    wafLogs = json.loads(line)
                    webAclArn = str(wafLogs['webaclId'])
                    terminatingRuleId = str(wafLogs['terminatingRuleId'])
                    action = str(wafLogs['action'])
                    httpSourceName = str(wafLogs['httpSourceName'])
                    httpSourceId = str(wafLogs['httpSourceId'])
                    clientIp = str(wafLogs['httpRequest']['clientIp'])
                    clientCountry = str(wafLogs['httpRequest']['country'])
                    uri = str(wafLogs['httpRequest']['uri'])
                    httpMethod = str(wafLogs['httpRequest']['httpMethod'])
                    for headers in wafLogs['httpRequest']['headers']:
                        if str(headers['name']) == 'User-Agent':
                            try:
                                userAgent = str(headers['value'])
                            except:
                                userAgent = 'Unidentified'    
                        else:
                            pass
        except Exception as e:
            print(e)
            raise

        def anomaly_check():
            # create sagemaker and ddb vars
            smEndpoint = os.environ['SAGEMAKER_ENDPOINT']
            anomalyDdbTable = os.environ['ANOMALY_DYNAMODB_TABLE']
            # create user-agent, IP pair with periods parsed out from the user-agent
            newUserAgent = userAgent.replace('.','')
            noCommas = newUserAgent.replace(',','')
            pair = noCommas + ',' + clientIp
            response = runtime.invoke_endpoint(EndpointName=smEndpoint,ContentType='text/csv',Body=pair)
            result = json.loads(response['Body'].read().decode())
            prediction = float(result['predictions'][0]['dot_product'])
            if prediction <= 0.03:
                iso8601 = datetime.datetime.now().isoformat()
                ts = int(time.time())
                ttl = int(ts + 8*86000)
                try:
                    table = dynamodbResource.Table(anomalyDdbTable)
                    table.put_item(
                        Item={
                            'ANOMALY_IPV4': clientIp,
                            'entity': userAgent,
                            'iso-time': iso8601,
                            'ttl': ttl
                        }
                    )
                except Exception as e:
                    print(e)
                anomalyDict = { 'isAnomaly': 'True' }
                anomalyData = json.dumps(anomalyDict)
                return anomalyData
            else:
                anomalyDict = { 'isAnomaly': 'False' }
                anomalyData = json.dumps(anomalyDict)
                return anomalyData

        def waf_log_geoint_enrich():
            url = 'http://ip-api.com/json/' + clientIp + '?fields=status,message,lat,lon,isp,org,as,asname'
            r = requests.get(url)
            # handle throttling
            reqRemain = int(r.headers['X-Rl'])
            if reqRemain == 0:
                ttl = int(r.headers['X-Ttl'])
                waitTime = ttl + 1
                time.sleep(waitTime)
            else:
                ipJson = r.json()
                latitude = float(ipJson['lat'])
                longitude = float(ipJson['lon'])
                isp = str(ipJson['isp'])
                org = str(ipJson['org'])
                asn = str(ipJson['as'])
                asnName = str(ipJson['asname'])
                geoLoc = { 'clientLat': latitude, 'clientLon': longitude, 'clientIsp': isp, 'clientOrg': org, 'clientAs': asn, 'clientAsName': asnName }
                geoData = json.dumps(geoLoc)
                return geoData

        def threat_intel_enrichment():
            # import tables
            ipIocTable = os.environ['IP_IOC_DYNAMODB_TABLE']
            domainIocTable = os.environ['DOMAIN_IOC_DYNAMODB_TABLE']
            # try to find the hostname
            try:
                clientHostname = str(socket.gethostbyaddr(clientIp)[0])
            except:
                clientHostname = 'Unidentified'
            # check if the hostname (if matched)
            # matches any threats
            if clientHostname != 'Unidentified':
                try:
                    response = dynamodb.query(
                        TableName=domainIocTable,
                        KeyConditions={
                            'DOMAIN_IOC': { 
                                'AttributeValueList': [
                                    {
                                        'S': clientHostname
                                    }
                                ],
                                'ComparisonOperator': 'EQ'
                            }
                        }
                    )
                    if str(response['Items']) == '[]':
                        clientHostnameThreatMatch = 'False'
                    else:
                        clientHostnameThreatMatch = 'True'
                except Exception as e:
                    print(e)
            else:
                clientHostnameThreatMatch = 'False'
            # check if IP matches any threats
            try:
                response = dynamodb.query(
                    TableName=ipIocTable,
                    KeyConditions={
                        'IPV4_IOC': { 
                            'AttributeValueList': [
                                {
                                    'S': clientIp
                                }
                            ],
                            'ComparisonOperator': 'EQ'
                        }
                    }
                )
                if str(response['Items']) == '[]':
                    clientIpThreatMatch = 'False'
                else:
                    clientIpThreatMatch = 'True'
            except Exception as e:
                print(e)
            # create threat intel dict
            ipThreatIntel = { 'clientHostname': clientHostname, 'clientHostnameThreatMatch': clientHostnameThreatMatch, 'clientIpThreatMatch': clientIpThreatMatch }
            threatData = json.dumps(ipThreatIntel)
            return threatData
        
        def waf_log_decorator():
            # Parse IP Insights Data
            anomalyInt = json.loads(anomaly_check())
            anomalyCheck = str(anomalyInt['isAnomaly'])
            # Parse Client GeoInt
            geoInt = json.loads(waf_log_geoint_enrich())
            clientIpLatid = float(geoInt['clientLat'])
            clientIpLongt = float(geoInt['clientLon'])
            clientIsp = str(geoInt['clientIsp'])
            clientOrg = str(geoInt['clientOrg'])
            clientAs = str(geoInt['clientAs'])
            clientAsName = str(geoInt['clientAsName'])
            # Parse Client Threat Intel
            threatInt = json.loads(threat_intel_enrichment())
            clientHostname = str(threatInt['clientHostname'])
            clientHostnameThreatMatch = str(threatInt['clientHostnameThreatMatch'])
            clientIpThreatMatch = str(threatInt['clientIpThreatMatch'])
            # create timestamp
            date = datetime.datetime.now().replace(microsecond=0).isoformat()
            # create new WAF log dict
            wafLogRaw = {
                'date': date,
                'isAnomaly': anomalyCheck,
                'webAclArn': webAclArn,
                'terminatingRuleId': terminatingRuleId,
                'action': action,
                'httpSourceName': httpSourceName,
                'httpSourceId': httpSourceId,
                'uri': uri,
                'httpMethod': httpMethod,
                'userAgent': userAgent,
                'clientIp': clientIp,
                'clientCountry': clientCountry,
                'location': { 'lat':clientIpLatid, 'lon':clientIpLongt },
                'clientIsp': clientIsp,
                'clientOrg': clientOrg,
                'clientAs': clientAs,
                'clientAsName': clientAsName,
                'clientHostname': clientHostname,
                'clientHostnameThreatMatch': clientHostnameThreatMatch,
                'clientIpThreatMatch': clientIpThreatMatch
            }
            newWafLog = json.dumps(wafLogRaw)
            print(newWafLog)
            # import variables
            awsRegion = os.environ['AWS_REGION']
            accessKey = os.environ['AWS_ACCESS_KEY_ID']
            secretAccessKey = os.environ['AWS_SECRET_ACCESS_KEY']
            seshToken = os.environ['AWS_SESSION_TOKEN']
            # create auth token
            awsAuthToken = AWS4Auth(accessKey, secretAccessKey, awsRegion, 'es', session_token=seshToken)
            host = os.environ['ELASTICSEARCH_URL']
            index = 'waf-logs'
            # create requests items
            url = host + '/' + index + '/' + '_doc/'
            headers = { "Content-Type": "application/json" }
            r = requests.post(url, auth=awsAuthToken, data=newWafLog, headers=headers)
            print(r.json())

        def main():
            anomaly_check()
            waf_log_geoint_enrich()
            threat_intel_enrichment()
            waf_log_decorator()

        main()